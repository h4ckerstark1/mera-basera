const toggle = document.getElementById('toggle');
const status = document.getElementById('status');

function render(isOn) {
  toggle.checked = isOn;
  status.textContent = isOn ? 'ON' : 'OFF';
}

chrome.storage.local.get(['timerOn'], (res) => {
  render(!!res.timerOn);
});

toggle.addEventListener('change', () => {
  const isOn = toggle.checked;
  render(isOn);
  chrome.storage.local.set({ timerOn: isOn });

  if (isOn) {
    // fresh start each time it's turned on from popup
    chrome.storage.local.set({ timerRunning: true, startTimestamp: Date.now(), accumulatedSeconds: 0 });
  }
});
