(function () {
  let widgetEl = null;
  let intervalId = null;

  function formatTime(totalSeconds) {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = Math.floor(totalSeconds % 60);
    const pad = (n) => String(n).padStart(2, '0');
    return `${pad(h)}:${pad(m)}:${pad(s)}`;
  }

  function getElapsed(state) {
    const accumulated = state.accumulatedSeconds || 0;
    if (state.timerRunning && state.startTimestamp) {
      return accumulated + (Date.now() - state.startTimestamp) / 1000;
    }
    return accumulated;
  }

  function createWidget() {
    if (widgetEl) return;
    widgetEl = document.createElement('div');
    widgetEl.id = 'padhai-timer-widget';
    widgetEl.innerHTML = `
      <span class="ptw-icon">⏱️</span>
      <div>
        <span class="ptw-time">00:00:00</span>
        <span class="ptw-label">Padhai Timer</span>
      </div>
      <button class="ptw-btn ptw-stop">Stop</button>
      <button class="ptw-btn ptw-restart">Restart</button>
    `;
    document.documentElement.appendChild(widgetEl);

    widgetEl.addEventListener('click', (e) => {
      if (e.target.classList.contains('ptw-stop') || e.target.classList.contains('ptw-resume')) {
        handleStopResume();
      } else if (e.target.classList.contains('ptw-restart')) {
        handleRestart();
      }
    });

    makeDraggable(widgetEl);
  }

  function handleStopResume() {
    chrome.storage.local.get(['timerRunning', 'startTimestamp', 'accumulatedSeconds'], (state) => {
      if (state.timerRunning) {
        // Pause: fold elapsed into accumulated
        const accumulated = (state.accumulatedSeconds || 0) + (Date.now() - (state.startTimestamp || Date.now())) / 1000;
        chrome.storage.local.set({ timerRunning: false, accumulatedSeconds: accumulated });
      } else {
        // Resume
        chrome.storage.local.set({ timerRunning: true, startTimestamp: Date.now() });
      }
    });
  }

  function handleRestart() {
    chrome.storage.local.set({
      timerRunning: true,
      startTimestamp: Date.now(),
      accumulatedSeconds: 0
    });
  }

  function updateWidget(state) {
    if (!widgetEl) return;
    const timeEl = widgetEl.querySelector('.ptw-time');
    const btnEl = widgetEl.querySelector('.ptw-stop, .ptw-resume');
    timeEl.textContent = formatTime(getElapsed(state));

    if (state.timerRunning) {
      widgetEl.classList.remove('ptw-paused');
      btnEl.textContent = 'Stop';
      btnEl.className = 'ptw-btn ptw-stop';
    } else {
      widgetEl.classList.add('ptw-paused');
      btnEl.textContent = 'Resume';
      btnEl.className = 'ptw-btn ptw-resume';
    }
  }

  function removeWidget() {
    if (widgetEl) {
      widgetEl.remove();
      widgetEl = null;
    }
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
  }

  function refresh() {
    chrome.storage.local.get(['timerOn', 'timerRunning', 'startTimestamp', 'accumulatedSeconds'], (state) => {
      if (state.timerOn) {
        createWidget();
        updateWidget(state);
        if (!intervalId) {
          intervalId = setInterval(() => {
            chrome.storage.local.get(['timerOn', 'timerRunning', 'startTimestamp', 'accumulatedSeconds'], updateWidget);
          }, 1000);
        }
      } else {
        removeWidget();
      }
    });
  }

  function makeDraggable(el) {
    let offsetX, offsetY, dragging = false;
    el.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      dragging = true;
      offsetX = e.clientX - el.getBoundingClientRect().left;
      offsetY = e.clientY - el.getBoundingClientRect().top;
      el.style.transition = 'none';
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      el.style.left = `${e.clientX - offsetX}px`;
      el.style.top = `${e.clientY - offsetY}px`;
      el.style.right = 'auto';
      el.style.bottom = 'auto';
    });
    document.addEventListener('mouseup', () => { dragging = false; });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') refresh();
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'GET_TIMER_STATE') {
      chrome.storage.local.get(
        ['timerOn', 'timerRunning', 'startTimestamp', 'accumulatedSeconds'],
        (state) => {
          sendResponse({
            ...state,
            elapsedSeconds: getElapsed(state)
          });
        }
      );

      return true;
    }
  });

  refresh();
})();
